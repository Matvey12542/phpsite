#SXD20|20010|50525|50313|2013.06.19 11:36:16|test|0|5|36|
#TA news`6`16384|newsopt`6`16384|online`1`16384|param`2`16384|users`21`16384
#EOH

#	TC`news`utf8_general_ci	;
CREATE TABLE `news` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `news_id` int(11) NOT NULL,
  `news_lang` varchar(3) NOT NULL,
  `news_title` varchar(50) NOT NULL,
  `news_text` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8	;
#	TD`news`utf8_general_ci	;
INSERT INTO `news` VALUES 
(1,7,'ru','Зоголовок1','Страница на русском.1'),
(6,53,'en','News1','News text=))))) (='),
(7,54,'en','News 2','Text news2.'),
(8,55,'ru','Заголовок2','Текст новини 2.'),
(9,56,'ru','Новость 3','Текст новости 3.'),
(10,57,'en','News3','Netxt3.')	;
#	TC`newsopt`latin1_swedish_ci	;
CREATE TABLE `newsopt` (
  `news_id` int(10) NOT NULL AUTO_INCREMENT,
  `news_date` datetime NOT NULL,
  `news_visible` tinyint(1) NOT NULL,
  PRIMARY KEY (`news_id`)
) ENGINE=InnoDB AUTO_INCREMENT=58 DEFAULT CHARSET=latin1	;
#	TD`newsopt`latin1_swedish_ci	;
INSERT INTO `newsopt` VALUES 
(7,'2013-06-19 00:00:00',1),
(53,'2013-06-19 00:00:00',1),
(54,'2013-06-19 00:00:00',1),
(55,'2013-06-19 00:00:00',1),
(56,'2013-06-19 00:00:00',1),
(57,'2013-06-19 00:00:00',1)	;
#	TC`online`latin1_swedish_ci	;
CREATE TABLE `online` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `session` varchar(100) NOT NULL,
  `time` int(11) NOT NULL,
  `user` varchar(30) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=latin1	;
#	TD`online`latin1_swedish_ci	;
INSERT INTO `online` VALUES 
(18,'gnuegf6rle8k7u4mipc6iu6np4',1371625813,'root')	;
#	TC`param`latin1_swedish_ci	;
CREATE TABLE `param` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `text` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1	;
#	TD`param`latin1_swedish_ci	;
INSERT INTO `param` VALUES 
(1,'Privet ce perwa stroka)))'),
(2,'Privet ce 2 stroka!!!!')	;
#	TC`users`latin1_swedish_ci	;
CREATE TABLE `users` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `login` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `email` varchar(30) NOT NULL,
  `name` varchar(30) NOT NULL,
  `city` varchar(30) NOT NULL,
  `status` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=latin1	;
#	TD`users`latin1_swedish_ci	;
INSERT INTO `users` VALUES 
(1,'Matvey','751392','Matvey12542@rambler.ru','Kolya','Lutsk',1),
(2,'Neo','12345','sda@sd.as','Tolik','Kovel',0),
(3,'1234','123','','','',0),
(4,'root','root','','','',0),
(5,'root1','root2','','','',0),
(8,'Толик','1965','','','',0),
(9,'rootarf','rootsef','sef','sef','sef',1),
(13,'','','','','',1),
(14,'qw','1','1','1','1',1),
(15,'qwe','1','1','','',1),
(16,'xdf','sdf','sdf','','',1),
(17,'sdf','1','sdf','sfd','sfd',1),
(18,'Talyanchik','1965','Matveycom@rambler.ru','Толік','Луцьк',1),
(19,'Koya','1','Matvey12542@rambler.ru','Kolya','Lutsk',1),
(20,'k','1','1','K2','Lutsk',1),
(21,'r','1','1','1','1',1),
(22,'12','1','1','1','1',1),
(23,'rootrty','1','dg','dfh','fgh',1),
(24,'Kolya','1965','1@1.ru','Kolya','Lutsk',1),
(25,'123','123','123','123','132',1),
(26,'awd','awd','awd','awd','awd',1)	;
