#SXD20|20010|50531|50409|2013.07.22 18:24:03|shop|0|5|39|
#TA news`7`16384|newsopt`7`16384|online`1`16384|param`2`16384|users`22`16384
#EOH

#	TC`news`utf8_general_ci	;
CREATE TABLE `news` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `news_id` int(11) NOT NULL,
  `news_lang` varchar(3) NOT NULL,
  `news_title` varchar(50) NOT NULL,
  `news_text` text NOT NULL,
  `news_author` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8	;
#	TD`news`utf8_general_ci	;
INSERT INTO `news` VALUES 
(8,55,'en','State of emergency at the site in Samara: the blas','We drove up to Chapaevskie at the eleventh hour, making a huge detour due to the overlap in the landfill roads.\r\n\r\n- There are dozens of cars because of the explosions and turned pokorezhilo you that, tired of living? - Testified against traffic cops striving to drive through the dangerous highway drivers\r\n\r\nIn the Chapaevsk all unerringly knew where to place the residents of the settlement of Nagorno left homeless after explosions at Chapaevsky range. Item was in a local house of culture, there have found shelter about 100 people. There they could eat and drink water (all slept in a local orphanage.)',''),
(11,58,'en','In France Google presented an ultimatum because o','The French Office for the tracking of data protection on Thursday ordered the IT-giant Google to change its privacy policy, or to prepare for penalties. The French, therefore, led the European movement about forcing the searcher to a more transparent intentions and methods of collecting personal information about users, writes Reuters.\r\n\r\nThe National Commission for Information and Liberties of France pointed out that Google\'s privacy policy violates the law of the country.\r\n\r\nOffice gave the digital giant three months to change the rules - otherwise the corporation at risk to encounter a fine of up to 150 million euros, which may be followed by a second, in the amount of 300 thousand euros.\r\n\r\nThe act was the result of the Commission\'s annual anti-key search engine and largest postal service. Office stressed that the government of Spain, Britain, Germany, Italy and the Netherlands are willing to make a similar move in the coming weeks.',''),
(12,59,'ru','Ð§ÐŸ Ð½Ð° Ð¿Ð¾Ð»Ð¸Ð³Ð¾Ð½Ðµ Ð² Ð¡Ð°Ð¼Ð°Ñ€Ðµ: Ð’Ð·Ñ€','ÐœÑ‹ Ð¿Ð¾Ð´ÑŠÐµÑ…Ð°Ð»Ð¸ Ðº Ð§Ð°Ð¿Ð°ÐµÐ²ÑÐºÐ¸Ðµ Ð² Ð¾Ð´Ð¸Ð½Ð½Ð°Ð´Ñ†Ð°Ñ‚Ñ‹Ð¹ Ñ‡Ð°Ñ, Ð´ÐµÐ»Ð°Ñ Ð¾Ð³Ñ€Ð¾Ð¼Ð½Ñ‹Ð¹ ÐºÑ€ÑŽÐº Ð¸Ð·-Ð·Ð° Ð¿ÐµÑ€ÐµÐºÑ€Ñ‹Ñ‚Ð¸Ñ Ð½Ð° Ð¿Ð¾Ð»Ð¸Ð³Ð¾Ð½Ðµ Ð´Ð¾Ñ€Ð¾Ð³Ð¸. - Ð¡ÑƒÑ‰ÐµÑÑ‚Ð²ÑƒÑŽÑ‚ Ð´ÐµÑÑÑ‚ÐºÐ¸ Ð°Ð²Ñ‚Ð¾Ð¼Ð¾Ð±Ð¸Ð»ÐµÐ¹ Ð¸Ð·-Ð·Ð° Ð²Ð·Ñ€Ñ‹Ð²Ð¾Ð² Ð¸ Ð¿Ð¾Ð²ÐµÑ€Ð½ÑƒÐ»ÑÑ pokorezhilo Ð²Ð°Ð¼, Ñ‡Ñ‚Ð¾ ÑƒÑÑ‚Ð°Ð» Ð¾Ñ‚ Ð¶Ð¸Ð·Ð½Ð¸? - Ð”Ð°Ð» Ð¿Ð¾ÐºÐ°Ð·Ð°Ð½Ð¸Ñ Ð¿Ñ€Ð¾Ñ‚Ð¸Ð² Ð³Ð°Ð¸ÑˆÐ½Ð¸ÐºÐ¾Ð² ÑÑ‚Ñ€ÐµÐ¼Ð»ÐµÐ½Ð¸Ðµ Ð¿Ñ€Ð¾ÐµÑ…Ð°Ñ‚ÑŒ Ñ‡ÐµÑ€ÐµÐ· Ð¾Ð¿Ð°ÑÐ½Ñ‹Ðµ Ð²Ð¾Ð´Ð¸Ñ‚ÐµÐ»Ð¸ ÑˆÐ¾ÑÑÐµ Ð² Ð§Ð°Ð¿Ð°ÐµÐ²ÑÐºÐµ Ð²ÑÐµ Ð±ÐµÐ·Ð¾ÑˆÐ¸Ð±Ð¾Ñ‡Ð½Ð¾ Ð·Ð½Ð°Ð», ÐºÑƒÐ´Ð° Ð¿Ð¾Ð¼ÐµÑÑ‚Ð¸Ñ‚ÑŒ Ð¶Ð¸Ñ‚ÐµÐ»ÐµÐ¹ Ð¿Ð¾ÑÐµÐ»ÐºÐ° ÐÐ°Ð³Ð¾Ñ€Ð½Ñ‹Ð¹ Ð¾ÑÑ‚Ð°Ð»Ð¸ÑÑŒ Ð±ÐµÐ· ÐºÑ€Ð¾Ð²Ð° Ð¿Ð¾ÑÐ»Ðµ Ð²Ð·Ñ€Ñ‹Ð²Ð¾Ð² Ð½Ð° Ð¿Ð¾Ð»Ð¸Ð³Ð¾Ð½Ðµ Ð§Ð°Ð¿Ð°ÐµÐ²ÑÐºÐ¸Ð¹. ÐŸÑ€ÐµÐ´Ð¼ÐµÑ‚Ð¾Ð² Ð² Ð¼ÐµÑÑ‚Ð½Ð¾Ð¼ Ð´Ð¾Ð¼Ðµ ÐºÑƒÐ»ÑŒÑ‚ÑƒÑ€Ñ‹, Ñ‚Ð°Ð¼ Ð½Ð°ÑˆÐ»Ð¸ Ð¿Ñ€Ð¸ÑŽÑ‚ Ð¾ÐºÐ¾Ð»Ð¾ 100 Ñ‡ÐµÐ»Ð¾Ð²ÐµÐº. Ð¢Ð°Ð¼ Ð¾Ð½Ð¸ Ð¼Ð¾Ð³Ð»Ð¸ Ð¿Ð¾ÐµÑÑ‚ÑŒ Ð¸ Ð¿Ð¸Ñ‚ÑŒ Ð²Ð¾Ð´Ñƒ (Ð²ÑÐµ ÑÐ¿Ð°Ð»Ð¸ Ð² Ð¼ÐµÑÑ‚Ð½Ñ‹Ð¹ Ð¿Ñ€Ð¸ÑŽÑ‚.)',''),
(15,62,'ru','ÐœÐ°Ð»ÐµÐ½ÑŒÐºÐ°Ñ ÑÑ‚Ñ€Ð¾Ñ‡ÐºÐ°','ÐœÐ°Ð»ÐµÐ½ÑŒÐºÐ°Ñ ÑÑ‚Ñ€Ð¾ÐºÐ°.',''),
(16,63,'en','Little string','Text little string.',''),
(17,64,'ru','Ñ€Ð°Ð· Ð´Ð²Ð° Ñ‚Ñ€Ð¸ Ñ‡Ð¾Ñ‚Ð¸Ñ€Ð¸ Ð¿ÑÑ‚ÑŒ','Ð¢ÐµÑÑ‚ Ñ‚ÐµÑÑ‚ Ð°Ð²Ñ‚Ð¾Ñ€Ð°.','Neo'),
(31,78,'ru','1234532545555565wadwww','1234567898555','Neo')	;
#	TC`newsopt`latin1_swedish_ci	;
CREATE TABLE `newsopt` (
  `news_id` int(10) NOT NULL AUTO_INCREMENT,
  `news_date` datetime NOT NULL,
  `news_visible` tinyint(1) NOT NULL,
  PRIMARY KEY (`news_id`)
) ENGINE=InnoDB AUTO_INCREMENT=79 DEFAULT CHARSET=latin1	;
#	TD`newsopt`latin1_swedish_ci	;
INSERT INTO `newsopt` VALUES 
(55,'2013-06-20 00:00:00',1),
(58,'2013-06-20 00:00:00',1),
(59,'2013-06-20 00:00:00',1),
(62,'2013-06-27 00:00:00',1),
(63,'2013-06-27 00:00:00',1),
(64,'2013-07-15 00:00:00',1),
(78,'2013-07-22 00:00:00',1)	;
#	TC`online`latin1_swedish_ci	;
CREATE TABLE `online` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `session` varchar(100) NOT NULL,
  `time` int(11) NOT NULL,
  `user` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=latin1	;
#	TD`online`latin1_swedish_ci	;
INSERT INTO `online` VALUES 
(35,'r9gjps9nqdu9meob852vmte2r3',1374506465,'Matvey')	;
#	TC`param`latin1_swedish_ci	;
CREATE TABLE `param` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `text` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1	;
#	TD`param`latin1_swedish_ci	;
INSERT INTO `param` VALUES 
(1,'Privet ce perwa stroka)))'),
(2,'Privet ce 2 stroka!!!!')	;
#	TC`users`latin1_swedish_ci	;
CREATE TABLE `users` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `login` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `email` varchar(30) NOT NULL,
  `name` varchar(30) NOT NULL,
  `surname` varchar(255) CHARACTER SET utf8 NOT NULL,
  `city` varchar(30) NOT NULL,
  `status` tinyint(1) NOT NULL,
  `img` varchar(255) CHARACTER SET utf8 NOT NULL DEFAULT 'def.png',
  `data` date NOT NULL,
  `last_visited` date NOT NULL,
  `role` int(5) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=latin1	;
#	TD`users`latin1_swedish_ci	;
INSERT INTO `users` VALUES 
(1,'Matvey','751392','Matvey12542@rambler.ru','Kolya','','Lutsk',1,'kot02.jpg','0000-00-00','2013-07-22',2),
(2,'Neo','12345','sda@sd.as','Tolik','','Kovel',0,'','0000-00-00','2013-07-22',2),
(3,'redaktor','111','','','','',0,'','0000-00-00','2013-07-22',2),
(4,'root','root','root@root.ua','Kolya','ÐœÐ°Ñ‚ÐµÐ¹Ñ‡ÑƒÐº','',0,'images.jpeg','0000-00-00','2013-07-22',1),
(5,'root1','root2','','','','',0,'','0000-00-00','0000-00-00',2),
(8,'Толик','1965','','','','',0,'','0000-00-00','0000-00-00',0),
(9,'rootarf','rootsef','sef','sef','','sef',1,'','0000-00-00','0000-00-00',0),
(13,'12354','','','','','',1,'','0000-00-00','0000-00-00',0),
(14,'qw','1','1','1','','1',1,'','0000-00-00','0000-00-00',0),
(15,'qwe','1','1','','','',1,'','0000-00-00','0000-00-00',0),
(16,'xdf','sdf','sdf','','','',1,'','0000-00-00','0000-00-00',0),
(17,'sdf','1','sdf','sfd','','sfd',1,'','0000-00-00','0000-00-00',0),
(18,'Talyanchik','1965','Matveycom@rambler.ru','Толік','','Луцьк',1,'','0000-00-00','0000-00-00',0),
(19,'Koya','1','Matvey12542@rambler.ru','Kolya','','Lutsk',1,'','0000-00-00','0000-00-00',0),
(20,'k','1','1','K2','','Lutsk',1,'','0000-00-00','0000-00-00',0),
(21,'r','1','1','1','','1',1,'','0000-00-00','0000-00-00',0),
(22,'12','1','1','1','','1',1,'','0000-00-00','0000-00-00',0),
(23,'rootrty','1','dg','dfh','','fgh',1,'','0000-00-00','0000-00-00',0),
(24,'Kolya','1965','1@1.ru','Kolya','','Lutsk',1,'','0000-00-00','0000-00-00',0),
(25,'123','123','123','123','','132',1,'','0000-00-00','0000-00-00',0),
(26,'awd','awd','awd','awd','','awd',1,'','0000-00-00','0000-00-00',0),
(27,'ccc','111','c@c.ru','ccc','','ccc',1,'def.png','2013-07-15','2013-07-22',2)	;
